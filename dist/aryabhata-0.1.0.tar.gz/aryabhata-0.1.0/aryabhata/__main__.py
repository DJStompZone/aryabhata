from aryabhata.sqrt import sqrt_aryabhata

if __name__ == "__main__":
    print("Aryabhata square root")
    # TODO: Argparse for cli
    # sqrt_aryabhata(args)
